/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.verificadorpalindromo;

/**
 *
 * @author Monserrath Castro 4c
 */
public class VerificadorPalindromo {

    // MÉTODO PRINCIPAL DE EJECUCIÓN (Donde corre el programa)
    public static void main(String[] args) {
        String palabraPrueba = "radar";
        
        // Aquí llamamos a tu método wrapper 
        boolean resultado = esPalindromo(palabraPrueba);
        
        System.out.println("La palabra '" + palabraPrueba + "' ¿es palíndromo? " + resultado);
    }

    // 1. MÉTODO WRAPPER (El que usa el usuario o el main)
    public static boolean esPalindromo(String palabra) {
        return esPalindromoHelper(palabra, 0, palabra.length() - 1);
    }

    // 2. MÉTODO RECURSIVO (El motor de tu lógica)
    private static boolean esPalindromoHelper(String palabra, int inicio, int fin) {
        if (inicio >= fin) {
            return true; 
        }
        if (palabra.charAt(inicio) != palabra.charAt(fin)) {
            return false; // Caso base de fallo
        }
        return esPalindromoHelper(palabra, inicio + 1, fin - 1); // Paso recursivo
    }
}
